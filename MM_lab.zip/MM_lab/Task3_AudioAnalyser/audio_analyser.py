"""
Task 3 - Audio Analyser
Multimedia Lab Assignment

Reads a WAV audio file and reports:
  - Basic info (sample rate, channels, duration, bit depth)
  - RMS energy, peak amplitude
  - Zero crossing rate
  - Waveform plot
  - Spectrogram plot
"""

import os
import sys
import numpy as np
from scipy.io import wavfile
from scipy import signal as sps
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def analyse_audio(audio_path, output_dir="output"):
    os.makedirs(output_dir, exist_ok=True)
    base_name = os.path.splitext(os.path.basename(audio_path))[0]

    sr, data = wavfile.read(audio_path)

    # Normalize to mono float for analysis
    if data.ndim > 1:
        channels = data.shape[1]
        mono = data.mean(axis=1)
    else:
        channels = 1
        mono = data

    mono = mono.astype(np.float32)
    max_possible = np.iinfo(data.dtype).max if np.issubdtype(data.dtype, np.integer) else 1.0
    mono_norm = mono / max_possible

    duration = len(mono) / sr
    rms = float(np.sqrt(np.mean(mono_norm ** 2)))
    peak = float(np.max(np.abs(mono_norm)))

    zero_crossings = np.where(np.diff(np.signbit(mono_norm)))[0]
    zcr = len(zero_crossings) / duration

    report = {
        "file_name": os.path.basename(audio_path),
        "sample_rate": sr,
        "channels": channels,
        "duration_sec": round(duration, 2),
        "bit_depth": str(data.dtype),
        "rms_energy": round(rms, 4),
        "peak_amplitude": round(peak, 4),
        "zero_crossing_rate_per_sec": round(zcr, 2),
    }

    # Waveform plot
    time_axis = np.linspace(0, duration, len(mono_norm))
    plt.figure(figsize=(8, 3))
    plt.plot(time_axis, mono_norm, color="teal", linewidth=0.5)
    plt.title(f"Waveform - {report['file_name']}")
    plt.xlabel("Time (s)")
    plt.ylabel("Amplitude")
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f"{base_name}_waveform.png"))
    plt.close()

    # Spectrogram plot
    f, t_spec, Sxx = sps.spectrogram(mono_norm, sr)
    plt.figure(figsize=(8, 4))
    plt.pcolormesh(t_spec, f, 10 * np.log10(Sxx + 1e-10), shading="gouraud")
    plt.title(f"Spectrogram - {report['file_name']}")
    plt.xlabel("Time (s)")
    plt.ylabel("Frequency (Hz)")
    plt.colorbar(label="Power (dB)")
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f"{base_name}_spectrogram.png"))
    plt.close()

    return report


def print_report(report):
    print("=" * 50)
    print(f"AUDIO ANALYSIS REPORT: {report['file_name']}")
    print("=" * 50)
    print(f"Sample Rate      : {report['sample_rate']} Hz")
    print(f"Channels         : {report['channels']}")
    print(f"Duration         : {report['duration_sec']} sec")
    print(f"Bit Depth        : {report['bit_depth']}")
    print(f"RMS Energy       : {report['rms_energy']}")
    print(f"Peak Amplitude   : {report['peak_amplitude']}")
    print(f"Zero Crossing Rate: {report['zero_crossing_rate_per_sec']} / sec")
    print("=" * 50)


if __name__ == "__main__":
    audio_path = sys.argv[1] if len(sys.argv) > 1 else "sample_audio.wav"
    result = analyse_audio(audio_path)
    print_report(result)
