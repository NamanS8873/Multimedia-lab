"""
Task 2 - Video Analyser
Multimedia Lab Assignment

Reads a video and reports:
  - Basic info (resolution, fps, frame count, duration, codec)
  - Average brightness per frame (plotted over time)
  - Motion intensity per frame (frame differencing, plotted over time)
  - Saves sample frames (start / middle / end) and a motion heat frame
"""

import os
import sys
import cv2
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def analyse_video(video_path, output_dir="output"):
    os.makedirs(output_dir, exist_ok=True)
    base_name = os.path.splitext(os.path.basename(video_path))[0]

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise IOError(f"Could not open video: {video_path}")

    fps = cap.get(cv2.CAP_PROP_FPS)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    duration = frame_count / fps if fps else 0
    fourcc = int(cap.get(cv2.CAP_PROP_FOURCC))
    codec = "".join([chr((fourcc >> 8 * i) & 0xFF) for i in range(4)])

    brightness_series = []
    motion_series = []
    prev_gray = None
    frames_cache = []

    frame_idx = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        brightness_series.append(float(np.mean(gray)))

        if prev_gray is not None:
            diff = cv2.absdiff(gray, prev_gray)
            motion_series.append(float(np.mean(diff)))
        else:
            motion_series.append(0.0)
        prev_gray = gray

        if frame_idx in (0, frame_count // 2, max(frame_count - 1, 0)):
            frames_cache.append((frame_idx, frame.copy()))

        frame_idx += 1

    cap.release()

    report = {
        "file_name": os.path.basename(video_path),
        "resolution": f"{width}x{height}",
        "fps": round(fps, 2),
        "frame_count": frame_count,
        "duration_sec": round(duration, 2),
        "codec": codec,
        "avg_brightness": round(float(np.mean(brightness_series)), 2),
        "avg_motion_intensity": round(float(np.mean(motion_series[1:])) if len(motion_series) > 1 else 0.0, 2),
        "max_motion_frame": int(np.argmax(motion_series)) if motion_series else 0,
    }

    # Save sample frames
    for idx, frame in frames_cache:
        cv2.imwrite(os.path.join(output_dir, f"{base_name}_frame_{idx}.png"), frame)

    # Brightness plot
    plt.figure(figsize=(8, 4))
    plt.plot(brightness_series, color="orange")
    plt.title(f"Brightness Over Time - {report['file_name']}")
    plt.xlabel("Frame Number")
    plt.ylabel("Mean Brightness")
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f"{base_name}_brightness_plot.png"))
    plt.close()

    # Motion plot
    plt.figure(figsize=(8, 4))
    plt.plot(motion_series, color="red")
    plt.title(f"Motion Intensity Over Time - {report['file_name']}")
    plt.xlabel("Frame Number")
    plt.ylabel("Mean Frame Difference")
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f"{base_name}_motion_plot.png"))
    plt.close()

    return report


def print_report(report):
    print("=" * 50)
    print(f"VIDEO ANALYSIS REPORT: {report['file_name']}")
    print("=" * 50)
    print(f"Resolution       : {report['resolution']}")
    print(f"FPS              : {report['fps']}")
    print(f"Frame Count      : {report['frame_count']}")
    print(f"Duration         : {report['duration_sec']} sec")
    print(f"Codec            : {report['codec']}")
    print(f"Avg Brightness   : {report['avg_brightness']} / 255")
    print(f"Avg Motion       : {report['avg_motion_intensity']}")
    print(f"Most Motion @ Frame: {report['max_motion_frame']}")
    print("=" * 50)


if __name__ == "__main__":
    video_path = sys.argv[1] if len(sys.argv) > 1 else "sample_video.mp4"
    result = analyse_video(video_path)
    print_report(result)
