# MM Lab — Multimedia Lab Assignment

Python scripts for image, video, and audio analysis. Built for the
Multimedia Lab assignment.

## Structure

```
MM_lab/
├── Task1_ImageAnalyser/
│   ├── image_analyser.py
│   ├── sample_image1.jpg / sample_image2.jpg
│   └── output/            # generated reports, edge maps, histograms
├── Task2_VideoAnalyser/
│   ├── video_analyser.py
│   ├── sample_video.mp4
│   └── output/            # generated reports, frames, brightness/motion plots
├── Task3_AudioAnalyser/
│   ├── audio_analyser.py
│   ├── sample_audio.wav
│   └── output/            # generated reports, waveform, spectrogram
└── sample_media/          # scripts used to generate the sample video/audio
```

## Requirements

```
pip install opencv-python-headless numpy scipy matplotlib pillow
```

## Usage

```bash
# Task 1 - Image Analyser
cd Task1_ImageAnalyser
python3 image_analyser.py <path_to_image>

# Task 2 - Video Analyser
cd Task2_VideoAnalyser
python3 video_analyser.py <path_to_video>

# Task 3 - Audio Analyser
cd Task3_AudioAnalyser
python3 audio_analyser.py <path_to_wav_file>
```

Each script prints a text report to the console and saves visual outputs
(plots, edge maps, spectrograms, frames) into its `output/` folder.

## What each analyser reports

**Image Analyser** — dimensions, format, file size, brightness, contrast,
dominant colors (k-means), edge density (Canny), color histogram.

**Video Analyser** — resolution, fps, frame count, duration, codec,
average brightness, motion intensity (frame differencing) over time,
sample frames.

**Audio Analyser** — sample rate, channels, duration, bit depth, RMS
energy, peak amplitude, zero-crossing rate, waveform, spectrogram.

## Notes

- `sample_video.mp4` and `sample_audio.wav` are synthetically generated
  (see `sample_media/`) since no video/audio file was provided for the
  assignment — swap these for your own recordings before final submission.
