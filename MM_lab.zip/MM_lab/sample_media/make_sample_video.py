"""Generates a small synthetic test video (moving shapes) since no video
was supplied for the assignment. Replace sample_video.mp4 with your own
video file for the real submission."""
import cv2
import numpy as np

width, height, fps, seconds = 320, 240, 20, 5
out = cv2.VideoWriter("sample_video.mp4", cv2.VideoWriter_fourcc(*"mp4v"),
                       fps, (width, height))

n_frames = fps * seconds
for i in range(n_frames):
    frame = np.full((height, width, 3), (30, 30, 30), dtype=np.uint8)
    x = int((i / n_frames) * (width - 40))
    cv2.circle(frame, (x + 20, height // 2), 20, (0, 200, 255), -1)
    cv2.rectangle(frame, (width - 60, 20), (width - 20, 60), (255, 100, 0), -1)
    cv2.putText(frame, f"Frame {i}", (10, height - 15),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    out.write(frame)

out.release()
print("sample_video.mp4 created")
