"""Generates a small synthetic test audio file (a rising tone / chirp with
a bit of noise) since no audio was supplied for the assignment. Replace
sample_audio.wav with your own audio file for the real submission."""
import numpy as np
from scipy.io import wavfile

sr = 44100
duration = 4
t = np.linspace(0, duration, int(sr * duration), endpoint=False)

# Chirp tone from 220Hz to 880Hz + light noise, with a fade envelope
freq = np.linspace(220, 880, t.size)
tone = 0.5 * np.sin(2 * np.pi * freq * t)
noise = 0.02 * np.random.randn(t.size)
envelope = np.clip(np.minimum(t, duration - t) * 4, 0, 1)
signal = (tone + noise) * envelope

audio = np.int16(signal * 32767)
wavfile.write("sample_audio.wav", sr, audio)
print("sample_audio.wav created")
