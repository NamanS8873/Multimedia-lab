"""
Task 1 - Image Analyser
Multimedia Lab Assignment

Reads an image and reports:
  - Basic info (dimensions, format, file size, mode)
  - Brightness / contrast stats
  - Dominant colors
  - Edge count (Canny edge detection)
  - Color histogram (saved as PNG)
  - Edge-detected version of the image (saved as PNG)
"""

import os
import sys
import cv2
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def analyse_image(image_path, output_dir="output"):
    os.makedirs(output_dir, exist_ok=True)
    base_name = os.path.splitext(os.path.basename(image_path))[0]

    # --- Load with PIL for metadata, OpenCV for processing ---
    pil_img = Image.open(image_path)
    img_bgr = cv2.imread(image_path)
    img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)

    file_size_kb = os.path.getsize(image_path) / 1024

    report = {}
    report["file_name"] = os.path.basename(image_path)
    report["format"] = pil_img.format
    report["mode"] = pil_img.mode
    report["width"], report["height"] = pil_img.size
    report["file_size_kb"] = round(file_size_kb, 2)
    report["mean_brightness"] = round(float(np.mean(gray)), 2)
    report["contrast_std_dev"] = round(float(np.std(gray)), 2)

    # --- Dominant colors via k-means ---
    pixels = img_rgb.reshape(-1, 3).astype(np.float32)
    k = 5
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 1.0)
    _, labels, centers = cv2.kmeans(pixels, k, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
    counts = np.bincount(labels.flatten())
    order = np.argsort(-counts)
    dominant_colors = [tuple(int(c) for c in centers[i]) for i in order]
    report["dominant_colors_rgb"] = dominant_colors

    # --- Edge detection ---
    edges = cv2.Canny(gray, 100, 200)
    edge_pixel_count = int(np.count_nonzero(edges))
    report["edge_pixel_count"] = edge_pixel_count
    report["edge_density_percent"] = round(100 * edge_pixel_count / edges.size, 2)

    cv2.imwrite(os.path.join(output_dir, f"{base_name}_edges.png"), edges)

    # --- Histogram plot ---
    plt.figure(figsize=(8, 4))
    colors = ("r", "g", "b")
    for i, col in enumerate(colors):
        hist = cv2.calcHist([img_rgb], [i], None, [256], [0, 256])
        plt.plot(hist, color=col)
    plt.title(f"Color Histogram - {report['file_name']}")
    plt.xlabel("Pixel Intensity")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f"{base_name}_histogram.png"))
    plt.close()

    # --- Dominant color swatch ---
    swatch = np.zeros((100, 500, 3), dtype=np.uint8)
    step = 500 // k
    for i, color in enumerate(dominant_colors):
        swatch[:, i * step:(i + 1) * step] = color
    cv2.imwrite(os.path.join(output_dir, f"{base_name}_dominant_colors.png"),
                cv2.cvtColor(swatch, cv2.COLOR_RGB2BGR))

    return report


def print_report(report):
    print("=" * 50)
    print(f"IMAGE ANALYSIS REPORT: {report['file_name']}")
    print("=" * 50)
    print(f"Format          : {report['format']}")
    print(f"Mode            : {report['mode']}")
    print(f"Dimensions      : {report['width']} x {report['height']}")
    print(f"File Size       : {report['file_size_kb']} KB")
    print(f"Mean Brightness : {report['mean_brightness']} / 255")
    print(f"Contrast (std)  : {report['contrast_std_dev']}")
    print(f"Edge Pixels     : {report['edge_pixel_count']} ({report['edge_density_percent']}%)")
    print("Dominant Colors (RGB):")
    for c in report["dominant_colors_rgb"]:
        print(f"   {c}")
    print("=" * 50)


if __name__ == "__main__":
    image_path = sys.argv[1] if len(sys.argv) > 1 else "sample_image1.jpg"
    result = analyse_image(image_path)
    print_report(result)
